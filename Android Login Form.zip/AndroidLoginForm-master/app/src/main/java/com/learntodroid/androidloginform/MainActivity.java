package com.learntodroid.androidloginform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("Activity_Lifecycle","onCreate invoked");
        Toast.makeText(MainActivity.this,"Created",Toast.LENGTH_SHORT).show();



        usernameEditText = findViewById(R.id.activity_main_usernameEditText);
        passwordEditText = findViewById(R.id.activity_main_passwordEditText);
        loginButton = findViewById(R.id.activity_main_loginButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (usernameEditText.getText().length() > 0 && passwordEditText.getText().length() > 0) {
                    String toastMessage = "Username: " + usernameEditText.getText().toString() + ", Password: " + passwordEditText.getText().toString();
                    Toast.makeText(getApplicationContext(), toastMessage, Toast.LENGTH_SHORT).show();

                } else {
                    String toastMessage = "Username or Password are not populated";
                    Toast.makeText(getApplicationContext(), toastMessage, Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    protected void onStart() {
        super.onStart();
        Log.d("Activity_Lifecycle", "onStart invoked");
        Toast.makeText(MainActivity.this, "Start", Toast.LENGTH_SHORT).show();
    }
    protected void onResume() {
        super.onResume();
        Log.d("Activity_Lifecycle", "onResume invoked");
        Toast.makeText(MainActivity.this, "Resume", Toast.LENGTH_SHORT).show();
    }
    protected void onPause() {
        super.onPause();
        Log.d("Activity_Lifecycle", "onPause invoked");
        Toast.makeText(MainActivity.this, "Pause", Toast.LENGTH_SHORT).show();
    }
    protected void onStop() {
        super.onStop();
        Log.d("Activity_Lifecycle", "onStop invoked");
        Toast.makeText(MainActivity.this, "Stop", Toast.LENGTH_SHORT).show();
    }
    protected void onRestart() {
        super.onRestart();
        Log.d("Activity_Lifecycle", "onRestart invoked");
        Toast.makeText(MainActivity.this, "Restart", Toast.LENGTH_SHORT).show();
    }
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Activity_Lifecycle","onDestroy invoked");
        Toast.makeText(MainActivity.this,"Destroy",Toast.LENGTH_SHORT).show();
    }





    public void homepage(View view) {
        Intent intent =new Intent(MainActivity.this,home.class);
        startActivity(intent);
    }
}