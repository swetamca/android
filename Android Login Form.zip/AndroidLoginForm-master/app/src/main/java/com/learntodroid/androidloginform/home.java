package com.learntodroid.androidloginform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;

public class home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }


    public void gal(View view) {
        Intent intent = new Intent(home.this, gallery.class);
        startActivity(intent);

    }

    public void about(View view) {
        Intent intent = new Intent(home.this, aboutus.class);
        startActivity(intent);
    }
    public void gocontact(View view)  {
        Intent intent = new Intent(home.this, ContactusActivity.class);
        startActivity(intent);
    }
}