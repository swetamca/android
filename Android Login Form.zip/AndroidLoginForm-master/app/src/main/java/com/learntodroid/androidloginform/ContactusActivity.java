package com.learntodroid.androidloginform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class ContactusActivity extends AppCompatActivity {
    private static String value;
    public static String getValue() {
        return value;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactus);
        private static String value;
        public static String getValue() {
            return value;
        }
    }

    public void map(View view) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://goo.gl/maps/e6xztDokmXC6MXPR8"));
        startActivity(i);

    }

    public void travel(View view) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.travelblog.org/"));
        startActivity(i);
    }

    public void youtube(View view) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtu.be/AivQS90Uu4E"));
        startActivity(i);

    }
}